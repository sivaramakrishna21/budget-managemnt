export const environment = {
  production: true,
  firebase :{
    apiKey: "AIzaSyBYbv09i6f57GIG-2fyH2qnU8OpTZ34Vpw",
    authDomain: "budget-39b91.firebaseapp.com",
    databaseURL: "https://budget-39b91.firebaseio.com",
    projectId: "budget-39b91",
    storageBucket: "budget-39b91.appspot.com",
    messagingSenderId: "406069528481",
    appId: "1:406069528481:web:69b7c665ce4040dabbede0",
    measurementId: "G-W2REGB9XW0"
  }
};
