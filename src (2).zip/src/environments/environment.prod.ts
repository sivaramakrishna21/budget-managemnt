export const environment = {
  production: true,
  firebase :{
    //place firebase keys here
  }
};
